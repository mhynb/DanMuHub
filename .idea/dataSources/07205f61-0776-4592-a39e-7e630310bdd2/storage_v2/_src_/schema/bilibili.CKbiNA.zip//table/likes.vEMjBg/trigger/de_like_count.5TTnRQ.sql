create definer = root@`%` trigger de_like_count
    after delete
    on likes
    for each row
BEGIN
    UPDATE video_data
    SET like_count = GREATEST(like_count - 1, 0)
    WHERE video_id = OLD.video_id;
END;

