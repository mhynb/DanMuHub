create definer = root@`%` trigger increment_like_count
    after insert
    on likes
    for each row
BEGIN
    UPDATE video_data
    SET like_count = like_count + 1
    WHERE video_id = NEW.video_id;
END;

