create definer = root@`%` trigger de_collect_count
    after delete
    on collect
    for each row
BEGIN
    UPDATE video_data
    SET collect_count = GREATEST(collect_count - 1, 0)
    WHERE video_id = OLD.video_id;
END;

