create definer = root@`%` trigger increment_danmaku_count
    after insert
    on danmaku
    for each row
BEGIN
    UPDATE video_data
    SET danmaku_count = danmaku_count + 1
    WHERE video_id = NEW.video_id;
END;

